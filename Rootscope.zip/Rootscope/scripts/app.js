/**
 * Created by BALASUBRAMANIAM on 21-02-2016.
 */
app = angular.module('MyApp',[]);
app.run(function($rootScope) {
    $rootScope.name = "Ari Lerner";
    $rootScope.color = "yellow";
});
app.controller('ParentController',['$scope',function($scope)
{

    $scope.customer={
    name:"Anoop"
}
    //unit testing


}]);

app.controller('ChildController',['$scope','$http','$rootScope',function($scope,$http,$rootScope)
{
    $http.get('https://api.github.com/users/girishgoudar').success(function(data, status, headers) {
        $scope.data = data;
    });
    $scope.sayHello= function()
    {
       aref=document.getElementsByTagName('a');
        $scope.greeting = "Welcome" + $scope.customer.name+$rootScope.name;
        aref[0].innerHTML=$scope.greeting;
    }
}]);

app.controller('GroverController', function($scope) {

    $scope.color = 'blue';

});

app.controller('SunController', function($scope) {

});


app.controller('mainController', function ($scope) {
    $scope.location = 'chennai';
});
app.directive('myDirective', function () {
    return {
        restrict: 'E',
        //isolated scope
        scope: {},
        template: '<div><input type="text" ng-model="location" /></div>'
    };

});


app.controller("firstCtrl", function ($scope) {
    $scope.$on('eventName', function (event, args) {
        $scope.message = args.message;
        console.log($scope.message);
    });
});

app.controller("secondCtrl", function ($scope) {
    $scope.handleClick = function (msg) {
        $scope.$emit('eventName', { message: msg });
    };
});


app.controller("thirdCtrl", function ($scope) {
    $scope.handleClick = function (msg) {
        $scope.$broadcast('trainingName', { message: msg });
    };

});

app.controller("fourthCtrl", function ($scope) {
    $scope.$on('trainingName', function (event, args) {
        $scope.message = args.message;
        console.log($scope.message);
    });
});
app.controller("fifthCtrl", function ($scope) {
    $scope.$on('trainingName', function (event, args) {
        $scope.message = args.message;
        console.log($scope.message);
    });
});


app.directive('aGreatEye', function () {
    return {
        restrict: 'E',
        replace: true,
        template: '<h1>lidless, wreathed in flame, {{1 + 1}} times</h1>'
    };
});