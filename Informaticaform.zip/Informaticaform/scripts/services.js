/**
 * Created by BALASUBRAMANIAM on 17-03-2016.
 */
serviceapp = angular.module('ServiceApp',[]);

serviceapp.service('CustomerDataService',['$http',function($http)
{
    var getCustomerList=function()
    {

        return   $http({
            method: 'GET',
            dataType: "jsonp",

            headers: {
                'Content-Type': 'application/json'
            },
            url: 'http://localhost:7070/FinancialService/rest/InfoUserService'



        }).success(function(info)
        {
            return info;

        }).error(function(x) {
            return x;
        });

    };


    return{
        getCustomerData:getCustomerList
    }
}]);



serviceapp.service('DataService',['$q','$http',function($q,$http)
{
    var getList=function(param)
    {
        var defer=$q.defer();
        var data;
        $http({
            method: 'GET',
            dataType: "jsonp",

            headers: {
                'Content-Type': 'application/json'
            },
            url: 'http://jsonplaceholder.typicode.com/'+param



        }).success(function(info)
        {
           data=info;
            defer.resolve(info);

        }).error(function(x) {
           defer.reject(x);
        });
        console.log(data);//undefined
        console.log(defer.promise);
        return defer.promise;
    };


    return{
        getData:getList
    }
}]);






