/**
 * Created by BALASUBRAMANIAM on 16-03-2016.
 */
var formmodule = angular.module('FormModule',['ngMessages','ui.router','ServiceApp','DataModule']);

var roles = {
    superUser: 0,
    admin: 1,
    user: 2
};

var routeForUnauthorizedAccess = '/SomeAngularRouteForUnauthorizedAccess';




formmodule.factory('RandomFactory', function ($http,$q) {
    serviceInstance={};
    serviceInstance.permissionCheck=function(x)
    {
        console.log('calling');
        defer=$q.defer();


        $http({
            method: 'GET',
            dataType: "jsonp",

            headers: {
                'Content-Type': 'application/json'
            },
            url: 'http://localhost:7070/FinancialService/rest/PermissionService'



        }).success(function(info)
        {
            //console.log(info);
            defer.resolve(info);
        }).error(function(x) {
            //console.log(x.error());
            defer.reject(x);
        });
      return  defer.promise.then(function(info)
       {
           defer=$q.defer();
           console.log( info.permission);

                 if(x==0)
                 {
                   if(info.permission=='superUser')
                       defer.resolve(true);
                 }
           else
                 {
                     defer.reject(false);
                 }
           //console.log(serviceInstance.permissionPassed) ;
           defer.promise.then(function(info)
           {
               console.log(info);
           })
           return defer.promise;
       })


    }
return serviceInstance;

});
formmodule.config(function ($httpProvider) {
    $httpProvider.interceptors.push(function ($q,$location) {
        return {
            request: function (config) {
                console.log(config.url);
               // config.url = config.url + '?id=123';
                //console.log(config.url);
                return config || $q.when(config);

            },
            requestError: function (config) {
                console.log(config.url);
                config.url = config.url + '?id=123';
                console.log(config.url);
                return config || $q.when(config);

            },

            response: function (response) {
                // parsing the response logic will come here.
                //console.log(this.request);
                console.log(response);
                // if(response.status==404)
                // response.
                return response;
            },
            responseError: function (response) {
                // parsing the response logic will come here.
                //console.log(this.request);
                console.log(response);
                if(response.status==404)
                   {
                        $location.path="/ImageData";
                    }
                return response;
            }

        }
    });
});
formmodule.config(function ($stateProvider, $urlRouterProvider) {

    $urlRouterProvider.when("", "/Login");

    $stateProvider
        .state("Login", {
            url: "/Login",
            templateUrl: "Login.html",
            controller: 'LoginController',
            activetab: 'Login'



        })
        .state("FormData", {
            url: "/FormData",
            templateUrl: "FormData.html",
            activetab: 'FormData'
        })
        .state("CustomerData", {
            url:"/CustomerData",
            templateUrl: "customerdata.html",
            controller: 'CustomerController',
            activetab: 'CustomerData',

            resolve: {
                permission: function (RandomFactory) {
                    return RandomFactory.permissionCheck([roles.admin]);
                }
            }
        })
        .state("ImageData", {
            url:"/ImageData",
            templateUrl: "ImageData.html",
            controller: 'ImageController',
            activetab: 'ImageData'

        })
        .state("DataServices", {
            url:"/DataServices",
            templateUrl: "DataServices.html",
            controller: 'DataServicesController',
            activetab: 'DataServices'

        })



});

/*
ConfigurationProvider = function($routeProvider)
{
    $routeProvider
        .when('/CustomerData', {
            templateUrl: 'customerdata.html',
            controller : 'CustomerController'
        }).

        otherwise({
            redirectTo: '/'
        });



};

formmodule.config(['$routeProvider', ConfigurationProvider]);
*/

formmodule.controller('LoginController',['$scope',function($scope)
{

$scope.user={
    userName:'',
    password:''
};
$scope.login=function()
{
    //authorization.login(credentials).success(success).error(error);
    var success = function (data) {
    var token = data.token;

    //api.init(token);

    //$cookieStore.put('token', token);
    //$location.path('/');
    };

    var error = function () {
        // TODO: apply user notification here..
    };

}






}]);



formmodule.controller('RegisterationController',['$scope','$filter','$http',function($scope,$filter,$http)
{
  $scope.person= {
      userId:0,
      userName:'',
      dob:new Date(22, 9, 1998),
      address:'',
      email:'',
      phoneNo:0
       };

  $scope.submit=function()
  {

      $scope.person.userId=Math.round((Math.random(100000)*10000),0);

      $scope.person.dob = $filter('date')($scope.person.dob, "dd-MM-yyyy");
      console.log($scope.person);
      userdata=JSON.stringify($scope.person);


      $http({
          method: 'POST',
          dataType: "jsonp",
          data:userdata,
          headers: {
              'Content-Type': 'application/json'
          },
          url: 'http://localhost:7070/FinancialService/rest/INFODataAPI'



      }).success(function(info)
      {
          console.log(info);
      }).error(function(x) {
          console.log(x.error());
      });
  }


}]);















formmodule.controller('CustomerController',['$scope','CustomerDataService',
    function($scope,CustomerDataService)
    {
        console.log("Reaching.....");
        $scope.modify = function(tableData){

            $scope.modifyField = true;
            $scope.viewField = true;
        };


        $scope.update = function(tableData){
            $scope.modifyField = false;
            $scope.viewField = false;
        };

        CustomerDataService.getCustomerData().then(function(info) {

            $scope.customerlist=info.data;
            console.log($scope.customerlist);

        });

    }]);
formmodule.constant('curr', ['INR','EUR','USD']);
formmodule.controller('ImageController',['$scope','$http','curr',
    function($scope,$http,curr)
    {
        $scope.options=curr;
        $scope.curoption='';
        $scope.currchange=function()
        {
            console.log($scope.curoption);
            console.log("Reaching.....");

            //$scope.data= { code:$scope.currencycode }
            //jsondata=JSON.stringify($scope.data);
            $http({
                method: 'POST',
                dataType: "jsonp",
                data: $scope.curoption,
                headers: {
                    'Content-Type': 'application/json'
                },
                url: 'http://localhost:7070/FinancialService/rest/CurrencyInfoAPI'



            }).success(function(info)
            {
                //console.log(info);
                $scope.imagedata=info;
                console.log($scope.imagedata);
            }).error(function(x) {
                console.log(x.error());
            });


        }



    }]);

