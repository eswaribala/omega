/**
 * Created by BALASUBRAMANIAM on 22-02-2016.
 */
describe('App Module', function() {

    beforeEach(module('MyApp'));//Any setup that needs to happen for each test

    var $httpBackend, $rootScope;
    var ParentController,
        scope;

    beforeEach(inject(function ($rootScope, $controller) {
        scope = $rootScope.$new();
        ParentController = $controller('ParentController', {
            $scope: scope
        });
    }));
    it('says hello!', function () {
        expect(scope.customer.name).toEqual('Anoop');
    });






    // Store references to $rootScope and $compile
    // so they are available to all tests in this describe block
    beforeEach(inject(function(_$compile_, _$rootScope_){
        // The injector unwraps the underscores (_) from around the parameter names when matching
        $compile = _$compile_;
        $rootScope = _$rootScope_;
    }));

    it('Replaces the element with the appropriate content', function() {
        //Setup, Act, Expect
        // Compile a piece of HTML containing the directive
        var element = $compile("<a-great-eye></a-great-eye>")($rootScope);
        // fire all the watches, so the scope expression {{1 + 1}} will be evaluated
        $rootScope.$digest();
        // Check that the compiled element contains the templated content
        expect(element.html()).toContain("lidless, wreathed in flame, 2 times");
    });







})
