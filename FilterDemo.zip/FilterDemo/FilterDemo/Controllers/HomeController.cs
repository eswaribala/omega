﻿using FilterDemo.Filters;
using FilterDemo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FilterDemo.Controllers
{
    
    [LogFilter]
    [ExceptionFilter]
    [AuthenticationFilter]
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            Product product = null;

            try
            {
                product.ProductName = "Laptop";
            }
            catch(NullReferenceException exception)
            {
                LogManager.ExceptionLog(exception.Message, exception);
            }
            
            return View();
        }
    }
}