﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Routing;

namespace FilterDemo.Models
{
    public class LogManager
    {
        public static void Log(String Name, RouteData routeData)
        {
            FileStream file = new FileStream(@"F:\TESCOOCTBATCH5\Logger\LogFile.txt", FileMode.Append);
           StreamWriter sw = new StreamWriter(file);


           var controllerName = routeData.Values["controller"];
           var actionName = routeData.Values["action"];
           var message = String.Format("{0} controller:{1} action:{2} accessd at{3}", Name, controllerName, actionName,DateTime.Now);
           sw.WriteLine(message);
           sw.WriteLine("-------------------------"); 
           sw.Close();
           file.Close();

        }
        public static void ExceptionLog(String Name, Exception exception)
        {
            FileStream file = new FileStream(@"F:\TESCOOCTBATCH5\Logger\ExceptionLog.txt", FileMode.Append);
            StreamWriter sw = new StreamWriter(file);


            
            var message = String.Format("{0} Exception Message{1} accessd at{2}", Name, exception.Message,DateTime.Now);
            sw.WriteLine(message);
            sw.WriteLine("-------------------------");
            sw.Close();
            file.Close();

        }
        public static void AuthenticationLog(String Name, String data)
        {
            FileStream file = new FileStream(@"F:\TESCOOCTBATCH5\Logger\AuthenticationLog.txt", FileMode.Append);
            StreamWriter sw = new StreamWriter(file);



            var message = String.Format("{0} Identity Name{1} accessd at{2}", Name, data, DateTime.Now);
            sw.WriteLine(message);
            sw.WriteLine("-------------------------");
            sw.Close();
            file.Close();

        }

    }
}